<?php

return [

    'name'              => 'Embedwhatsapp',
    'description'       => 'This is my awesome module',

];