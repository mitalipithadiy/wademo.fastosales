<?php

return [

    'name'              => 'Flowiseai',
    'description'       => 'This is my awesome module',

];