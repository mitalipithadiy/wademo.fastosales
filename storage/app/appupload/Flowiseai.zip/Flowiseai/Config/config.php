<?php

return [
    'name' => 'Flowiseai'
];
