<?php

return [

    'name'              => 'Translatechat',
    'description'       => 'This is my awesome module',

];