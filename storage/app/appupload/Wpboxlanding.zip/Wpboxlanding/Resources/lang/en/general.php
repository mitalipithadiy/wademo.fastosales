<?php

return [

    'name'              => 'Wpboxlanding',
    'description'       => 'This is my awesome module',

];